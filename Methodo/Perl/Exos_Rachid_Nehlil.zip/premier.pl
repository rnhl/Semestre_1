#!usr/bin/perl -w

print("entrez nombre ?  ");
$nombre = <STDIN>; chomp $nombre;

$nb_premier = (2 ** ($nombre - 1)) - 1;

if($nb_premier % $nombre eq 0 && $nombre > 1){
	print("$nombre est premier\n"); 
}
else{
	print("$nombre n'est pas premier\n");
}


#Le programme fonctionne pour tous les nombres à l'exception de 2 
#à cause de la formule ci-dessus.

